//go:build windows

package cli

const (
	TERMINAL_CLEAR_LINE = "\r\r"
)
